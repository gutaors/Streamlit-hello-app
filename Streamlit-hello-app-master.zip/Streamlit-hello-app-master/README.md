# Streamlit-app
Sample repository for youtube video

<h2>You can read the 'steps to follow.txt' file and follow those steps to successfuly deploy your Streamlit app on Heroku. </h2>
